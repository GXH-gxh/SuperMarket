<template>
    <div id="app">
        <!--用来显示组件-->
        <router-view></router-view>
    </div>
</template>

<script>
</script>

<style>
    #app{
        height: 100%;
    }
</style>